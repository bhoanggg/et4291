#include "/home/bhoanggg/Downloads/pintos-anon-master/src/tests/lib.h"
#include "/home/bhoanggg/Downloads/pintos-anon-master/src/tests/main.h"

void
test_main (void) 
{
  CHECK(mkdir("testdir"), "mkdir testdir");
  CHECK(chdir("testdir"), "chdir testdir");

  msg("Current directory changed to 'testdir' successfully.");
  exit(0);
}
