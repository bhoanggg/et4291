#include "tests/lib.h"
#include "tests/main.h"

void
test_main (void) 
{
  CHECK(mkdir("dir1"), "mkdir dir1");
  CHECK(chdir("dir1"), "chdir dir1");
  CHECK(chdir(".."), "chdir ..");

  int fd = open(".");
  char name[READDIR_MAX_LEN + 1];
  bool found = false;

  while (readdir(fd, name)) 
    {
      if (strcmp(name, "dir1") == 0) 
        {
          found = true;
          break;
        }
    }
  close(fd);
  CHECK(found, "readdir found dir1");

  msg("Readdir test passed.");
  exit(0);
}
