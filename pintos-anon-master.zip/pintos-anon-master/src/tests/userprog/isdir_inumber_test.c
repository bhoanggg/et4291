#include "tests/lib.h"
#include "tests/main.h"

void
test_main (void) 
{
  CHECK(mkdir("dirtest"), "mkdir dirtest");

  int fd = open("dirtest");
  CHECK(fd >= 2, "open dirtest");

  CHECK(isdir(fd), "isdir dirtest");

  int inum = inumber(fd);
  msg("Inode number of dirtest: %d", inum);

  close(fd);

  msg("isdir and inumber test passed.");
  exit(0);
}
