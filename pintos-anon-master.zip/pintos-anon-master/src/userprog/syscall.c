#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "filesys/filesys.h"
#include "filesys/file.h"
#include "filesys/inode.h"
#include "filesys/directory.h"
#include "devices/shutdown.h"
#include "threads/vaddr.h"
#include "userprog/process.h"
#include <stdbool.h>

static void syscall_handler (struct intr_frame *);

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
  uint32_t *esp = f->esp;
  if (!is_user_vaddr(esp))
    thread_exit();

  int syscall_number = *esp;

  switch (syscall_number) {
    case SYS_HALT:
      shutdown_power_off();
      break;

    case SYS_EXIT:
      if (!is_user_vaddr(esp + 1)) thread_exit();
      int status = *(esp + 1);
      process_exit();;
      break;

    case SYS_OPEN:
      {
        const char *filename = (const char *) *(esp + 1);
        if (!is_user_vaddr(filename) || filename == NULL || filename[0] == '\0') {
         f->eax = -1;
        break;
        }
        struct inode *inode = resolve_path(filename);
        if (inode == NULL) {
          f->eax = -1;
          break;
        }
        f->eax = process_add_file(inode);
        break;
      }

    case SYS_MKDIR:
      {
        const char *dir = (const char *) *(esp + 1);
        if (!is_user_vaddr(dir)) {
          f->eax = false;
          break;
        }
        f->eax = sys_mkdir(dir);
        break;
      }

    case SYS_CHDIR:
      {
        const char *dir = (const char *) *(esp + 1);
        if (!is_user_vaddr(dir)) {
          f->eax = false;
          break;
        }
        f->eax = sys_chdir(dir);
        break;
      }

    case SYS_ISDIR:
      {
        int fd = *(esp + 1);
        f->eax = sys_isdir(fd);
        break;
      }

    case SYS_INUMBER:
      {
        int fd = *(esp + 1);
        f->eax = sys_inumber(fd);
        break;
      }

    default:
      printf ("Unknown system call %d\n", syscall_number);
      thread_exit();
  }
}

// Các hàm hệ thống hỗ trợ

bool sys_mkdir(const char *path) {
  char parent_path[256], name[NAME_MAX + 1];
  if (!split_path(path, parent_path, name)) return false;

  struct inode *parent = resolve_path(parent_path);
  if (!parent || !inode_is_dir(parent)) return false;

  struct dir *parent_dir = dir_open(parent);
  if (!parent_dir) return false;

  if (dir_lookup(parent_dir, name, NULL)) {
    dir_close(parent_dir);
    return false;
  }

  block_sector_t sector;
  if (!free_map_allocate(1, &sector)) {
    dir_close(parent_dir);
    return false;
  }

  // Tạo thư mục trống với dung lượng ban đầu là 16 mục
  block_sector_t parent_sector = inode_get_inumber(dir_get_inode(thread_current()->cwd));
if (!dir_create(sector, 16, parent_sector)) {
    free_map_release(sector, 1);
    dir_close(parent_dir);
    return false;
  }

  // Mở thư mục mới để thêm "." và ".."
  struct dir *new_dir = dir_open(inode_open(sector));
  if (!new_dir) {
    free_map_release(sector, 1);
    dir_close(parent_dir);
    return false;
  }

  // Gán "." trỏ tới chính nó
  if (!dir_add(new_dir, ".", sector)) {
    dir_close(new_dir);
    free_map_release(sector, 1);
    dir_close(parent_dir);
    return false;
  }

  // Gán ".." trỏ tới thư mục cha
  if (!dir_add(new_dir, "..", inode_get_inumber(dir_get_inode(parent_dir)))) {
    dir_close(new_dir);
    free_map_release(sector, 1);
    dir_close(parent_dir);
    return false;
  }

  dir_close(new_dir);

  // Thêm thư mục mới vào thư mục cha
  if (!dir_add(parent_dir, name, sector)) {
    free_map_release(sector, 1);
    dir_close(parent_dir);
    return false;
  }

  dir_close(parent_dir);
  return true;
}


bool sys_chdir(const char *path) {
  struct inode *inode = resolve_path(path);
  if (!inode || !inode_is_dir(inode)) return false;
  process_set_current_dir(inode);
  return true;
}

bool sys_isdir(int fd) {
  struct file *f = process_get_file(fd);
  if (!f) return false;
  return inode_is_dir(file_get_inode(f));
}

int sys_inumber(int fd) {
  struct file *f = process_get_file(fd);
  if (!f) return -1;
  return inode_get_inumber(file_get_inode(f));
}

bool sys_readdir(int fd, char *name) {
  struct file *file = process_get_file(fd);
  if (!file || !inode_is_dir(file_get_inode(file)))
    return false;

  // Mở lại dir từ inode (không reset dir->pos vì file giữ vị trí)
  struct dir *dir = dir_open(file_get_inode(file));
  if (!dir)
    return false;

  bool found = false;
  while (dir_readdir(dir, name)) {
    if (strcmp(name, ".") != 0 && strcmp(name, "..") != 0) {
      found = true;
      break;
    }
  }

  dir_close(dir);
  return found;
}

int sys_open(const char *path)
{
  struct inode *inode = resolve_path(path);
  if (inode == NULL)
    return -1;

  int fd = process_add_file(inode);
  if (fd < 0)
    inode_close(inode);

  return fd;
}


