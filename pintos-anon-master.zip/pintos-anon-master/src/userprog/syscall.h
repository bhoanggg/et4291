#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H
#include <stdbool.h>


void syscall_init(void);

bool sys_mkdir(const char *dir);
bool sys_chdir(const char *path);
bool sys_isdir(int fd);
int sys_inumber(int fd);

#endif /* userprog/syscall.h */
