int main(void) {
  mkdir("/a");
  return 0;
}
