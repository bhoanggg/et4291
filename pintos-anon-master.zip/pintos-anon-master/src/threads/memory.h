#ifndef THREADS_MEMORY_H
#define THREADS_MEMORY_H

#include "threads/thread.h"
#include "threads/synch.h"
#include <stddef.h>

/**
 * @brief Cấu trúc lưu thông tin một vùng nhớ được cấp phát
 * Mỗi khi malloc được gọi, một memory_region sẽ được tạo
 */
struct memory_region {
    void *start_addr;       ///< Địa chỉ bắt đầu vùng nhớ (do user sử dụng)
    size_t size;            ///< Kích thước vùng nhớ (bytes)
    struct list_elem elem;  ///< Liên kết vào danh sách của thread
};

/* Biến toàn cục */
extern struct lock memory_lock;  ///< Lock bảo vệ truy cập memory tracking

/**
 * @brief Khởi tạo hệ thống tracking bộ nhớ
 * Gọi từ thread_init() khi hệ thống khởi động
 */
void memory_tracking_init(void);

/**
 * @brief Phiên bản tracked của malloc
 * @param size Kích thước cần cấp phát
 * @return void* Con trỏ vùng nhớ, hoặc NULL nếu thất bại
 * @note Thay thế hoàn toàn cho malloc() thông thường
 */
void *tracked_malloc(size_t size);

/**
 * @brief Phiên bản tracked của free
 * @param ptr Con trỏ cần giải phóng
 * @note Thay thế hoàn toàn cho free() thông thường
 */
void tracked_free(void *ptr);

/**
 * @brief Hiển thị thông tin bộ nhớ của thread (dùng cho debug)
 * @param t Thread cần kiểm tra
 */
void thread_dump_memory_info(struct thread *t);

#endif /* threads/memory.h */