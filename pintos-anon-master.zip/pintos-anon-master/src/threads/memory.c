#include "threads/thread.h"
#include "threads/malloc.h"
#include "threads/synch.h"   // Để sử dụng lock
#include "lib/stdio.h"       // Để debug (printf)

/* Lock bảo vệ truy cập vào memory tracking */
static struct lock memory_lock;

/* Cấu trúc lưu thông tin vùng nhớ được cấp phát */
struct memory_region {
    void *start_addr;        // Địa chỉ bắt đầu vùng nhớ
    size_t size;             // Kích thước vùng nhớ (bytes)
    struct list_elem elem;   // Phần tử danh sách
};

/* Khởi tạo hệ thống tracking bộ nhớ */
void
memory_tracking_init(void)
{
    lock_init(&memory_lock);
    printf("Memory tracking initialized\n");
}

/* Cập nhật thống kê bộ nhớ của thread */
static void
update_memory_usage(struct thread *t, size_t size, bool is_alloc)
{
    lock_acquire(&memory_lock);
    
    if (is_alloc) {
        t->memory_usage += size;
        if (t->memory_usage > t->peak_memory) {
            t->peak_memory = t->memory_usage;
        }
    } else {
        t->memory_usage -= size;
    }
    
    lock_release(&memory_lock);
}

/* Phiên bản tracked của malloc */
void *
tracked_malloc(size_t size)
{
    /* Cấp phát thêm sizeof(size_t) bytes để lưu kích thước */
    void *ptr = malloc(size + sizeof(size_t));
    if (!ptr) {
        printf("malloc(%zu) failed\n", size);
        return NULL;
    }

    /* Lưu kích thước vào 4 bytes đầu */
    *(size_t *)ptr = size;
    
    /* Con trỏ trả về cho người dùng (bỏ qua header) */
    void *ret_ptr = (char *)ptr + sizeof(size_t);

    /* Tạo bản ghi tracking */
    struct memory_region *region = malloc(sizeof(struct memory_region));
    if (!region) {
        free(ptr);
        return NULL;
    }

    region->start_addr = ret_ptr;
    region->size = size;

    /* Thêm vào danh sách tracking của thread hiện tại */
    struct thread *cur = thread_current();
    list_push_back(&cur->memory_regions, &region->elem);
    
    update_memory_usage(cur, size, true);

    printf("Allocated %zu bytes at %p\n", size, ret_ptr);
    return ret_ptr;
}

/* Phiên bản tracked của free */
void
tracked_free(void *ptr)
{
    if (!ptr) return;

    /* Lấy lại con trỏ thực (có chứa header) */
    void *real_ptr = (char *)ptr - sizeof(size_t);
    size_t size = *(size_t *)real_ptr;

    /* Xóa khỏi danh sách tracking */
    struct thread *cur = thread_current();
    struct list_elem *e;
    
    for (e = list_begin(&cur->memory_regions); 
         e != list_end(&cur->memory_regions); 
         e = list_next(e)) 
    {
        struct memory_region *r = list_entry(e, struct memory_region, elem);
        if (r->start_addr == ptr) {
            list_remove(e);
            free(r);
            break;
        }
    }

    update_memory_usage(cur, size, false);
    free(real_ptr);
    
    printf("Freed %zu bytes at %p\n", size, ptr);
}

/* Hàm debug: In thông tin bộ nhớ của thread */
void
dump_memory_info(struct thread *t)
{
    printf("Thread %d ('%s') memory usage:\n", t->tid, t->name);
    printf("  Current: %zu bytes\n", t->memory_usage);
    printf("  Peak:    %zu bytes\n", t->peak_memory);
    
    if (!list_empty(&t->memory_regions)) {
        printf("  Allocated regions:\n");
        struct list_elem *e;
        for (e = list_begin(&t->memory_regions); 
             e != list_end(&t->memory_regions); 
             e = list_next(e)) 
        {
            struct memory_region *r = list_entry(e, struct memory_region, elem);
            printf("    %p - %zu bytes\n", r->start_addr, r->size);
        }
    }
}