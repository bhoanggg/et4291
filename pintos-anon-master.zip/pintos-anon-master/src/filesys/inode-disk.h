#ifndef FILESYS_INODE_DISK_H
#define FILESYS_INODE_DISK_H

#include <stdbool.h>
#include "devices/block.h"
#include "filesys/off_t.h"

struct inode_disk {
    block_sector_t start;    // sector bắt đầu
    off_t length;            // độ dài file
    bool is_dir;             // true nếu là thư mục
    // ... các trường khác như magic, hoặc mảng sector ...
};

#endif /* filesys/inode_disk.h */
